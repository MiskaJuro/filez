PrimeCraft: 7x7 Faithful
PrimeCraft: 7x7 Custom
Shee-PvP
+ Any other resource packs with this document

Copyright Info:
This resource pack is Copyright ©2013 of WeeHeeHee (reddit.com/u/weeheehee and youtube.com/weeheeheeib) and is the intellectual property of WeeHeeHee. Only Curse.com and Planetminecraft.com have my express permission to host downloads of the original and/or derived versions using resources sourced from this resource pack.

You may:
- Take screenshots and videos and post on third party websites
- Link to this resource pack's download page (URLs below) for other Minecraft gamers to enjoy!

You may not:
- Re-create any of these resource packs without written permission
- Edit/use/modify the textures or any art assets without written permission
- Upload any of WeeHeeHee's resource pack files to any third party servers
- Claim as your own project / re-distribute in ANY way
- Use ANY part of PrimeCraft and/or Shee-PvP for profit using such things as Adfly links.

In order to update this resource pack, visit:

http://www.curse.com/texture-packs/minecraft/prime-craft-7x7-faithful
http://www.curse.com/texture-packs/minecraft/prime-craft-7x7-custom
http://www.curse.com/texture-packs/minecraft/shee-pvp

Attributions:
Lamb with adult sheep image by Alan Cleaver. Permission given for use under CC license.
Lamb in hay by Paula Funnell. Permission given for use under CC license.

If this resource pack and any contained resources breach copyright or if you have any other issues, please contact me at http://reddit.com/u/weeheehee (preferred) or http://youtube.com/weeheeheeib (preferred) or by email at uggamahfuggana@hotmail.com